#ifndef DCHAT_H
#define DCHAT_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <string>
#include <iostream>
#include <map>
#include <set>
#include <vector>
#include <deque>
#include <sysexits.h>
#include <signal.h>
#include <iterator>
#include <pthread.h>

#include "utility.h"

using namespace std;

class dchat
{
public:
	// Store all the members' info in the current group
	map<string, string> all_members_list; // <"ip_address:port", "name">
	// Store the leader's "ip_address:port" info
	string leader;
	// Store my own "ip_address:port" info
	string my_addr;
	string my_name;
	bool is_leader;
	

	int sock, sock2, num, len;
    struct sockaddr_in me;
    struct sockaddr_in other;


	dchat() {
		all_members_list = map<string, string>();
	}
	string get_ip_address();
	void start_new_group(string l_name);
	void join_a_group(string m_name, string l_addr);
	// void elect_a_leader();
};

// vector<string> split(string str, string sep) {

//     vector<string> arr;
//     char* curr;
//     char* cstr = const_cast<char*>(str.c_str());
//     curr = strtok(cstr, sep.c_str());
//     while (curr != NULL) {
//         arr.push_back(string(curr));
//         curr = strtok(NULL, sep.c_str());
//     }
//     return arr;
// }

int start_a_leader(dchat *p_chat, string l_addr) {

    char *p_laddr = new char[l_addr.length()+1];
    strcpy(p_laddr, l_addr.c_str());

    char *ip_addr, *portno;
    ip_addr = strtok(p_laddr, ":");
    portno = strtok(NULL, ":");

    p_chat->sock = socket(AF_INET, SOCK_DGRAM, 0); 
    if (p_chat->sock < 0) {
        return p_chat->sock;
    }

    bzero((char *) &(p_chat->me), sizeof(p_chat->me)); 
    p_chat->me.sin_family = AF_INET;
    p_chat->me.sin_addr.s_addr = inet_addr(ip_addr);
    p_chat->me.sin_port = htons(atoi(portno));

    p_chat->sock2 = ::bind(p_chat->sock, (struct sockaddr *) &(p_chat->me), sizeof(p_chat->me));
    if (p_chat->sock2 < 0) {
        return p_chat->sock2;
    }
    return 0;
}

int start_a_regular_member(dchat *p_chat, string l_addr, string m_addr, string m_name) {

    char *p_maddr = new char[m_addr.length()+1];
    strcpy(p_maddr, m_addr.c_str());

    char *ip_addr_me, *portno_me;
    ip_addr_me = strtok(p_maddr, ":");
    portno_me = strtok(NULL, ":");

    p_chat->sock = socket(AF_INET, SOCK_DGRAM, 0); 
    if (p_chat->sock < 0) {
        return p_chat->sock;
    }

    bzero((char *) &(p_chat->me), sizeof(p_chat->me)); 
    p_chat->me.sin_family = AF_INET;
    p_chat->me.sin_addr.s_addr = inet_addr(ip_addr_me);
    p_chat->me.sin_port = htons(atoi(portno_me));

    p_chat->sock2 = ::bind(p_chat->sock, (struct sockaddr *) &(p_chat->me), sizeof(p_chat->me));
    if (p_chat->sock2 < 0) {
        return p_chat->sock2;
    }

    char *p_laddr = new char[l_addr.length()+1];
    strcpy(p_laddr, l_addr.c_str());

    char *ip_addr_other, *portno_other;
    ip_addr_other = strtok(p_laddr, ":");
    portno_other = strtok(NULL, ":");

    bzero((char *) &(p_chat->other), sizeof(p_chat->other)); 
    p_chat->other.sin_family = AF_INET;
    p_chat->other.sin_addr.s_addr = inet_addr(ip_addr_other);
    p_chat->other.sin_port = htons(atoi(portno_other));

    char buff[2048];
    bzero(buff, 2048);

    int currtime = getLocalTime();  //get current time with utility function
    msgpack msg_pack(ip_addr_me, atoi(portno_me), m_name, currtime, 1, "N/A");
    string msg_sent = serialize(msg_pack);
    strcpy(buff, msg_sent.c_str());

    p_chat->num = sendto(p_chat->sock, buff, strlen(buff), 0, (struct sockaddr *) &(p_chat->other), sizeof(p_chat->other));
    if (p_chat->num < 0) {
        return p_chat->num;
    }
    p_chat->len = sizeof(p_chat->other);
    bzero((char *) &(p_chat->other), p_chat->len);
    bzero(buff, 2048);
    p_chat->num = recvfrom(p_chat->sock, buff, 2048, 0, (struct sockaddr *) &(p_chat->other), (socklen_t *) &(p_chat->len));
    if (p_chat->num < 0) {
        return p_chat->num;
    }
    string msg_recv = buff;
    msg_pack = deserialize(msg_recv);
    string members = msg_pack.msg;
    vector<string> vec = split(members, "\t");
    p_chat->leader = vec.back();
    vec.pop_back();
    while (!vec.empty()) {
        string key = vec.back();
        vec.pop_back();
        string val = vec.back();
        vec.pop_back();
        p_chat->all_members_list[key] = val;
    }

    return 0;
}
#endif